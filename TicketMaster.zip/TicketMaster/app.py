import os
import logging
from flask import Flask, render_template, send_from_directory

# Set up logging for easier debugging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key-for-development")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/add-ticket')
def add_ticket():
    return render_template('add-ticket.html')

@app.route('/tickets')
def tickets():
    return render_template('tickets.html')

@app.route('/ticket-details')
def ticket_details():
    return render_template('ticket-details.html')

@app.route('/my-achievements')
def my_achievements():
    return render_template('my-achievements.html')

@app.route('/warnings')
def warnings():
    return render_template('warnings.html')

@app.route('/admin-panel')
def admin_panel():
    return render_template('admin-panel.html')

@app.route('/logout')
def logout():
    return render_template('logout.html')

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
