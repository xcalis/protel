// auth.js - Handles authentication for PROTEL Ticket System

// Define user credentials
const users = {
    admin: {
        username: 'admin@ali',
        password: '@@2005@@2005',
        role: 'admin'
    },
    employees: [
        { username: 'emp_protel1', password: 'ptl2025a1', role: 'employee' },
        { username: 'emp_protel2', password: 'ptl2025b2', role: 'employee' },
        { username: 'emp_protel3', password: 'ptl2025c3', role: 'employee' },
        { username: 'emp_protel4', password: 'ptl2025d4', role: 'employee' },
        { username: 'emp_protel5', password: 'ptl2025e5', role: 'employee' },
        { username: 'emp_protel6', password: 'ptl2025f6', role: 'employee' },
        { username: 'emp_protel7', password: 'ptl2025g7', role: 'employee' },
        { username: 'emp_protel8', password: 'ptl2025h8', role: 'employee' }
    ]
};

// Check if user is logged in
function isLoggedIn() {
    return localStorage.getItem('protel_user') !== null;
}

// Get current user details
function getCurrentUser() {
    return JSON.parse(localStorage.getItem('protel_user'));
}

// Check if current user is admin
function isAdmin() {
    const user = getCurrentUser();
    return user && user.role === 'admin';
}

// Authenticate user
function authenticateUser(username, password, rememberMe) {
    // Check admin credentials
    if (username === users.admin.username && password === users.admin.password) {
        saveUserToStorage(users.admin, rememberMe);
        return { success: true, user: users.admin };
    }
    
    // Check employee credentials
    for (const employee of users.employees) {
        if (username === employee.username && password === employee.password) {
            saveUserToStorage(employee, rememberMe);
            return { success: true, user: employee };
        }
    }
    
    // Authentication failed
    return { success: false, message: 'Invalid username or password' };
}

// Save user to local storage
function saveUserToStorage(user, rememberMe) {
    localStorage.setItem('protel_user', JSON.stringify(user));
    if (rememberMe) {
        localStorage.setItem('protel_remember', 'true');
    }
}

// Logout user
function logoutUser() {
    localStorage.removeItem('protel_user');
    if (!localStorage.getItem('protel_remember')) {
        // If "remember me" wasn't checked, clear everything
        localStorage.removeItem('protel_remember');
    }
    window.location.href = '/';
}

// Protect pages based on authentication
function protectPage() {
    if (!isLoggedIn()) {
        window.location.href = '/';
    }
}

// Protect admin pages
function protectAdminPage() {
    if (!isLoggedIn() || !isAdmin()) {
        window.location.href = '/dashboard';
    }
}

// Initialize login page
function initLoginPage() {
    const loginForm = document.getElementById('login-form');
    const errorMessage = document.getElementById('error-message');
    const roleToggles = document.querySelectorAll('.role-toggle button');
    
    // Toggle between admin and employee role selection
    roleToggles.forEach(button => {
        button.addEventListener('click', function() {
            roleToggles.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            document.getElementById('role').value = this.dataset.role;
        });
    });
    
    // Handle form submission
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const rememberMe = document.getElementById('remember-me').checked;
            
            const result = authenticateUser(username, password, rememberMe);
            
            if (result.success) {
                // Redirect based on role
                if (result.user.role === 'admin') {
                    window.location.href = '/admin-panel';
                } else {
                    window.location.href = '/dashboard';
                }
            } else {
                // Show error message
                errorMessage.textContent = result.message;
                errorMessage.style.display = 'block';
            }
        });
    }
    
    // Check if user is already logged in
    if (isLoggedIn()) {
        const user = getCurrentUser();
        if (user.role === 'admin') {
            window.location.href = '/admin-panel';
        } else {
            window.location.href = '/dashboard';
        }
    }
}

// Check for auto login on page load
document.addEventListener('DOMContentLoaded', function() {
    // If on login page, initialize login functionality
    if (document.getElementById('login-form')) {
        initLoginPage();
    }
    
    // Protect pages based on URL
    const currentPath = window.location.pathname;
    
    if (currentPath === '/admin-panel') {
        protectAdminPage();
    } else if (currentPath !== '/' && currentPath !== '/login') {
        protectPage();
    }
    
    // Update UI with user info if logged in
    if (isLoggedIn()) {
        const user = getCurrentUser();
        const userDisplayElements = document.querySelectorAll('.user-display');
        
        userDisplayElements.forEach(element => {
            element.textContent = user.username;
        });
        
        // Show/hide elements based on role
        const adminElements = document.querySelectorAll('.admin-only');
        adminElements.forEach(element => {
            element.style.display = isAdmin() ? 'block' : 'none';
        });
    }
});
