// admin.js - Handles admin functionality for PROTEL Ticket System

// Initialize warnings storage if it doesn't exist
function initWarningsStorage() {
    if (!localStorage.getItem('protel_warnings')) {
        localStorage.setItem('protel_warnings', JSON.stringify([]));
    }
}

// Get all warnings
function getAllWarnings() {
    return JSON.parse(localStorage.getItem('protel_warnings') || '[]');
}

// Create a new warning
function createWarning(warningData) {
    const user = JSON.parse(localStorage.getItem('protel_user'));
    if (!user || user.role !== 'admin') {
        return { success: false, message: 'Unauthorized' };
    }
    
    const newWarning = {
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        createdBy: user.username,
        ...warningData
    };
    
    const warnings = getAllWarnings();
    warnings.push(newWarning);
    localStorage.setItem('protel_warnings', JSON.stringify(warnings));
    
    return { success: true, warning: newWarning };
}

// Delete a warning
function deleteWarning(warningId) {
    const user = JSON.parse(localStorage.getItem('protel_user'));
    if (!user || user.role !== 'admin') {
        return { success: false, message: 'Unauthorized' };
    }
    
    const warnings = getAllWarnings();
    const updatedWarnings = warnings.filter(warning => warning.id !== warningId);
    
    if (warnings.length === updatedWarnings.length) {
        return { success: false, message: 'Warning not found' };
    }
    
    localStorage.setItem('protel_warnings', JSON.stringify(updatedWarnings));
    
    return { success: true };
}

// Initialize admin panel page
function initAdminPanelPage() {
    // Check if user is admin
    const user = JSON.parse(localStorage.getItem('protel_user') || '{}');
    if (!user || user.role !== 'admin') {
        window.location.href = '/dashboard';
        return;
    }
    
    const warningForm = document.getElementById('warning-form');
    const warningsContainer = document.getElementById('warnings-container');
    
    if (!warningForm || !warningsContainer) return;
    
    // Initialize storage
    initWarningsStorage();
    
    // Handle form submission
    warningForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const warningData = {
            title: document.getElementById('warning-title').value,
            message: document.getElementById('warning-message').value,
            priority: document.getElementById('warning-priority').value
        };
        
        const result = createWarning(warningData);
        
        if (result.success) {
            // Reset form
            warningForm.reset();
            
            // Refresh warnings list
            displayWarnings();
            
            // Show success message
            document.getElementById('success-message').style.display = 'block';
            setTimeout(() => {
                document.getElementById('success-message').style.display = 'none';
            }, 3000);
        }
    });
    
    // Display existing warnings
    function displayWarnings() {
        const warnings = getAllWarnings();
        
        if (warnings.length === 0) {
            warningsContainer.innerHTML = '<div class="card"><p class="text-center">No warnings or announcements.</p></div>';
            return;
        }
        
        let warningsHTML = '';
        
        warnings.forEach(warning => {
            const createdDate = new Date(warning.createdAt).toLocaleString();
            const priorityClass = warning.priority === 'high' ? 'btn-danger' : 
                                warning.priority === 'medium' ? 'btn-warning' : 'btn-outline';
            
            warningsHTML += `
                <div class="admin-announcement card fade-in">
                    <div class="card-header">
                        <h3>${warning.title}</h3>
                        <span class="${priorityClass} p-1">${warning.priority} priority</span>
                    </div>
                    <p class="mb-2">Posted on: ${createdDate}</p>
                    <p class="mb-3">${warning.message}</p>
                    <div class="text-right">
                        <button class="btn btn-danger delete-warning" data-id="${warning.id}">Delete</button>
                    </div>
                </div>
            `;
        });
        
        warningsContainer.innerHTML = warningsHTML;
        
        // Add event listeners to delete buttons
        const deleteButtons = document.querySelectorAll('.delete-warning');
        deleteButtons.forEach(button => {
            button.addEventListener('click', function() {
                const warningId = this.dataset.id;
                const result = deleteWarning(warningId);
                
                if (result.success) {
                    // Refresh warnings list
                    displayWarnings();
                }
            });
        });
    }
    
    // Display warnings on page load
    displayWarnings();
}

// Initialize warnings page
function initWarningsPage() {
    const warningsContainer = document.getElementById('warnings-container');
    if (!warningsContainer) return;
    
    // Initialize storage
    initWarningsStorage();
    
    // Get all warnings
    const warnings = getAllWarnings();
    
    // Display warnings
    if (warnings.length === 0) {
        warningsContainer.innerHTML = '<div class="card"><p class="text-center">No warnings or announcements.</p></div>';
    } else {
        let warningsHTML = '';
        
        warnings.forEach(warning => {
            const createdDate = new Date(warning.createdAt).toLocaleString();
            const priorityClass = warning.priority === 'high' ? 'btn-danger' : 
                                warning.priority === 'medium' ? 'btn-warning' : 'btn-outline';
            
            warningsHTML += `
                <div class="warning-message fade-in">
                    <div class="warning-header">
                        <h3>${warning.title} <span class="${priorityClass} p-1">${warning.priority} priority</span></h3>
                        <p class="warning-date">Posted on: ${createdDate}</p>
                    </div>
                    <p>${warning.message}</p>
                </div>
            `;
        });
        
        warningsContainer.innerHTML = warningsHTML;
    }
}

// Initialize admin functionality on page load
document.addEventListener('DOMContentLoaded', function() {
    // Initialize warnings storage
    initWarningsStorage();
    
    // Check which page we're on
    const currentPath = window.location.pathname;
    
    if (currentPath === '/admin-panel') {
        initAdminPanelPage();
    } else if (currentPath === '/warnings') {
        initWarningsPage();
    }
});
