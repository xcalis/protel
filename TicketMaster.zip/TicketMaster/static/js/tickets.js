// tickets.js - Handles ticket functionality for PROTEL Ticket System

// Initialize ticket storage if it doesn't exist
function initTicketStorage() {
    if (!localStorage.getItem('protel_tickets')) {
        localStorage.setItem('protel_tickets', JSON.stringify([]));
    }
}

// Get all tickets
function getAllTickets() {
    return JSON.parse(localStorage.getItem('protel_tickets') || '[]');
}

// Get tickets for current user
function getUserTickets() {
    const user = JSON.parse(localStorage.getItem('protel_user'));
    if (!user) return [];
    
    const tickets = getAllTickets();
    
    // Return all tickets for admin, or user-specific tickets for employees
    if (user.role === 'admin') {
        return tickets;
    } else {
        return tickets.filter(ticket => ticket.assignedTo === user.username);
    }
}

// Get ticket by ID
function getTicketById(ticketId) {
    const tickets = getAllTickets();
    return tickets.find(ticket => ticket.id === ticketId);
}

// Generate a unique ticket ID
function generateTicketId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Create a new ticket
function createTicket(ticketData) {
    const user = JSON.parse(localStorage.getItem('protel_user'));
    if (!user) return { success: false, message: 'User not logged in' };
    
    const newTicket = {
        id: generateTicketId(),
        createdAt: new Date().toISOString(),
        status: 'open',
        createdBy: user.username,
        ...ticketData
    };
    
    const tickets = getAllTickets();
    tickets.push(newTicket);
    localStorage.setItem('protel_tickets', JSON.stringify(tickets));
    
    // Update achievements
    updateAchievements(user.username);
    
    return { success: true, ticket: newTicket };
}

// Update ticket status
function updateTicketStatus(ticketId, status, resolution) {
    const tickets = getAllTickets();
    const ticketIndex = tickets.findIndex(ticket => ticket.id === ticketId);
    
    if (ticketIndex === -1) {
        return { success: false, message: 'Ticket not found' };
    }
    
    const user = JSON.parse(localStorage.getItem('protel_user'));
    if (!user) {
        return { success: false, message: 'User not logged in' };
    }
    
    // Check if resolution note is provided when marking as done
    if (status === 'done' && !resolution) {
        return { success: false, message: 'Resolution note is required' };
    }
    
    // Update the ticket
    tickets[ticketIndex].status = status;
    tickets[ticketIndex].updatedAt = new Date().toISOString();
    tickets[ticketIndex].updatedBy = user.username;
    
    if (resolution) {
        tickets[ticketIndex].resolution = resolution;
    }
    
    localStorage.setItem('protel_tickets', JSON.stringify(tickets));
    
    // If marked as done, update achievements
    if (status === 'done') {
        updateAchievements(user.username);
    }
    
    return { success: true, ticket: tickets[ticketIndex] };
}

// Update achievements data
function updateAchievements(username) {
    // Initialize achievements storage if it doesn't exist
    if (!localStorage.getItem('protel_achievements')) {
        localStorage.setItem('protel_achievements', JSON.stringify({}));
    }
    
    const achievements = JSON.parse(localStorage.getItem('protel_achievements'));
    
    // Initialize user achievements if they don't exist
    if (!achievements[username]) {
        achievements[username] = {
            totalCompleted: 0,
            daily: {},
            weekly: {}
        };
    }
    
    // Get today's date in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0];
    
    // Get the week number (ISO week)
    const getWeekNumber = (date) => {
        const d = new Date(date);
        d.setHours(0, 0, 0, 0);
        d.setDate(d.getDate() + 3 - (d.getDay() + 6) % 7);
        const week1 = new Date(d.getFullYear(), 0, 4);
        return 1 + Math.round(((d - week1) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
    };
    
    const weekNumber = `${new Date().getFullYear()}-W${getWeekNumber(today)}`;
    
    // Update daily count
    achievements[username].daily[today] = (achievements[username].daily[today] || 0) + 1;
    
    // Update weekly count
    achievements[username].weekly[weekNumber] = (achievements[username].weekly[weekNumber] || 0) + 1;
    
    // Update total completed
    achievements[username].totalCompleted += 1;
    
    // Save achievements
    localStorage.setItem('protel_achievements', JSON.stringify(achievements));
}

// Get user achievements
function getUserAchievements(username) {
    const achievements = JSON.parse(localStorage.getItem('protel_achievements') || '{}');
    return achievements[username] || { totalCompleted: 0, daily: {}, weekly: {} };
}

// Initialize tickets page
function initTicketsPage() {
    const ticketsContainer = document.getElementById('tickets-container');
    if (!ticketsContainer) return;
    
    // Initialize storage
    initTicketStorage();
    
    // Get user tickets
    const tickets = getUserTickets();
    
    // Display tickets
    if (tickets.length === 0) {
        ticketsContainer.innerHTML = '<div class="card"><p class="text-center">No tickets found.</p></div>';
    } else {
        let ticketsHTML = '';
        
        tickets.forEach(ticket => {
            const createdDate = new Date(ticket.createdAt).toLocaleString();
            const statusClass = ticket.status === 'open' ? 'status-open' : 'status-done';
            
            ticketsHTML += `
                <div class="ticket card fade-in">
                    <div class="ticket-header">
                        <h3 class="ticket-title">${ticket.subject}</h3>
                        <span class="ticket-status ${statusClass}">${ticket.status}</span>
                    </div>
                    <div class="ticket-content">
                        <p><strong>Customer:</strong> ${ticket.customerName}</p>
                        <p><strong>Created:</strong> ${createdDate}</p>
                        <p><strong>Description:</strong> ${ticket.description.substring(0, 100)}${ticket.description.length > 100 ? '...' : ''}</p>
                    </div>
                    <div class="ticket-actions">
                        <a href="/ticket-details?id=${ticket.id}" class="btn">View Details</a>
                    </div>
                </div>
            `;
        });
        
        ticketsContainer.innerHTML = ticketsHTML;
    }
}

// Initialize add ticket page
function initAddTicketPage() {
    const addTicketForm = document.getElementById('add-ticket-form');
    if (!addTicketForm) return;
    
    // Initialize storage
    initTicketStorage();
    
    // Handle form submission
    addTicketForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const ticketData = {
            customerName: document.getElementById('customer-name').value,
            customerPhone: document.getElementById('customer-phone').value,
            customerAddress: document.getElementById('customer-address').value,
            subject: document.getElementById('ticket-subject').value,
            description: document.getElementById('ticket-description').value,
            priority: document.getElementById('ticket-priority').value,
            assignedTo: JSON.parse(localStorage.getItem('protel_user')).username
        };
        
        const result = createTicket(ticketData);
        
        if (result.success) {
            // Show success message
            document.getElementById('success-message').style.display = 'block';
            
            // Reset form
            addTicketForm.reset();
            
            // Redirect after a delay
            setTimeout(() => {
                window.location.href = '/tickets';
            }, 2000);
        }
    });
}

// Initialize ticket details page
function initTicketDetailsPage() {
    const ticketDetailsContainer = document.getElementById('ticket-details-container');
    const completeTicketForm = document.getElementById('complete-ticket-form');
    
    if (!ticketDetailsContainer) return;
    
    // Get ticket ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const ticketId = urlParams.get('id');
    
    if (!ticketId) {
        ticketDetailsContainer.innerHTML = '<div class="card"><p class="text-center">Ticket not found.</p></div>';
        return;
    }
    
    // Get ticket details
    const ticket = getTicketById(ticketId);
    
    if (!ticket) {
        ticketDetailsContainer.innerHTML = '<div class="card"><p class="text-center">Ticket not found.</p></div>';
        return;
    }
    
    // Display ticket details
    const createdDate = new Date(ticket.createdAt).toLocaleString();
    const updatedDate = ticket.updatedAt ? new Date(ticket.updatedAt).toLocaleString() : 'Not updated';
    const statusClass = ticket.status === 'open' ? 'status-open' : 'status-done';
    
    const ticketHTML = `
        <div class="ticket-detail-header">
            <h1>${ticket.subject}</h1>
            <span class="ticket-status ${statusClass}">${ticket.status}</span>
        </div>
        
        <div class="ticket-details card">
            <div class="ticket-section">
                <h3 class="ticket-section-title">Customer Information</h3>
                <p><strong>Name:</strong> ${ticket.customerName}</p>
                <p><strong>Phone:</strong> ${ticket.customerPhone}</p>
                <p><strong>Address:</strong> ${ticket.customerAddress}</p>
            </div>
            
            <div class="ticket-section">
                <h3 class="ticket-section-title">Ticket Information</h3>
                <p><strong>Created by:</strong> ${ticket.createdBy}</p>
                <p><strong>Created on:</strong> ${createdDate}</p>
                <p><strong>Updated on:</strong> ${updatedDate}</p>
                <p><strong>Priority:</strong> ${ticket.priority}</p>
            </div>
            
            <div class="ticket-section">
                <h3 class="ticket-section-title">Description</h3>
                <p>${ticket.description}</p>
            </div>
            
            ${ticket.resolution ? `
                <div class="ticket-section">
                    <h3 class="ticket-section-title">Resolution</h3>
                    <p>${ticket.resolution}</p>
                </div>
            ` : ''}
        </div>
    `;
    
    ticketDetailsContainer.innerHTML = ticketHTML;
    
    // Handle ticket completion
    if (completeTicketForm && ticket.status === 'open') {
        completeTicketForm.style.display = 'block';
        
        completeTicketForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const resolution = document.getElementById('resolution-note').value;
            
            const result = updateTicketStatus(ticketId, 'done', resolution);
            
            if (result.success) {
                // Reload page to show updated ticket
                window.location.reload();
            } else {
                // Show error message
                document.getElementById('error-message').textContent = result.message;
                document.getElementById('error-message').style.display = 'block';
            }
        });
    } else if (completeTicketForm) {
        completeTicketForm.style.display = 'none';
    }
}

// Initialize tickets functionality on page load
document.addEventListener('DOMContentLoaded', function() {
    // Initialize ticket storage
    initTicketStorage();
    
    // Check which page we're on
    const currentPath = window.location.pathname;
    
    if (currentPath === '/tickets') {
        initTicketsPage();
    } else if (currentPath === '/add-ticket') {
        initAddTicketPage();
    } else if (currentPath === '/ticket-details') {
        initTicketDetailsPage();
    }
});
